#!/usr/bin/env bash
# One-shot: refresh cache → verify model/list → relaunch Codex Desktop with CDP → patch Statsig.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="${CODEX_DESKTOP_APP:-/Applications/ChatGPT.app}"
CDP_PORT="${CDP_PORT:-9222}"

echo "==> [1/4] Refresh models cache"
python3 "$ROOT/scripts/refresh-models-cache.py" "$@"

echo "==> [2/4] Verify model/list"
python3 "$ROOT/scripts/verify-model-list.py"

if [[ ! -d "$APP" ]]; then
  echo "ERROR: Codex Desktop app not found at $APP" >&2
  echo "Set CODEX_DESKTOP_APP=/path/to/ChatGPT.app" >&2
  exit 1
fi

BUNDLE_ID="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP/Contents/Info.plist" 2>/dev/null || true)"
if [[ "$BUNDLE_ID" != "com.openai.codex" ]]; then
  echo "WARNING: $APP bundle id is '$BUNDLE_ID' (expected com.openai.codex)"
  echo "Make sure this is Codex Desktop, not ChatGPT Classic."
fi

echo "==> [3/4] Relaunch Desktop with remote debugging on :$CDP_PORT"
# Prefer quitting only the Codex Desktop instance.
if pgrep -f "$APP/Contents/MacOS/ChatGPT" >/dev/null 2>&1; then
  pkill -f "$APP/Contents/MacOS/ChatGPT" || true
  sleep 1
fi

open -na "$APP" --args --remote-debugging-port="$CDP_PORT" --remote-allow-origins='*'

echo "Waiting for CDP..."
for i in $(seq 1 40); do
  if curl -fsS "http://127.0.0.1:${CDP_PORT}/json/list" >/dev/null 2>&1; then
    break
  fi
  sleep 0.5
  if [[ "$i" -eq 40 ]]; then
    echo "ERROR: CDP port $CDP_PORT never became ready" >&2
    exit 1
  fi
done
sleep 2

echo "==> [4/4] Patch Statsig model allowlist"
python3 "$ROOT/scripts/patch-codex-model-picker.py"

echo
echo "Done. In Codex Desktop, reopen the model picker."
echo "Expect 5.6 Sol / Terra / Luna (not only 自定义/Custom)."
echo "Re-run this script after every full app restart (Statsig patch is in-memory)."
