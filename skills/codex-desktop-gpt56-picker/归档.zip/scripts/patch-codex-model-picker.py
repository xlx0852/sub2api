#!/usr/bin/env python3
"""Patch Codex Desktop Statsig allowlist so the model picker shows GPT-5.6.

Requires the app launched with remote debugging:
  open -na "/Applications/ChatGPT.app" --args --remote-debugging-port=9222 --remote-allow-origins=*

Then:
  python3 patch-codex-model-picker.py
"""
from __future__ import annotations

import asyncio
import json
import sys
import urllib.request

try:
    import websockets
except ImportError:
    import subprocess

    subprocess.check_call([sys.executable, "-m", "pip", "install", "websockets", "-q"])
    import websockets

CDP_HOST = "127.0.0.1"
CDP_PORT = 9222
CONFIG_NAME = "107580212"

INJECT = r"""
(() => {
  if (window.__codex56InjectInstalled) return 'already';
  window.__codex56InjectInstalled = true;
  const patched = {
    use_hidden_models: false,
    default_model: 'gpt-5.6-sol',
    available_models: [
      'gpt-5.6-sol',
      'gpt-5.6-terra',
      'gpt-5.6-luna',
      'gpt-5.5',
      'gpt-5.4',
      'gpt-5.4-mini',
      'gpt-5.2'
    ]
  };
  const apply = (obj) => {
    if (!obj || typeof obj !== 'object') return;
    if ('available_models' in obj || 'use_hidden_models' in obj || 'default_model' in obj) {
      obj.use_hidden_models = false;
      obj.default_model = 'gpt-5.6-sol';
      obj.available_models = patched.available_models.slice();
    }
  };
  const patchClient = (client) => {
    if (!client) return false;
    try {
      const vals = client._store?._values?.values;
      if (vals) for (const v of Object.values(vals)) apply(v);
      const dc = client._store?._values?.dynamic_configs || {};
      if (dc['107580212']?.value) apply(dc['107580212'].value);
    } catch {}
    if (!client.__codex56Patched) {
      try {
        const orig = client.getDynamicConfig.bind(client);
        client.getDynamicConfig = function(name, ...rest) {
          const cfg = orig(name, ...rest);
          if (String(name) === '107580212' && cfg?.value) apply(cfg.value);
          return cfg;
        };
      } catch {}
      client.__codex56Patched = true;
    }
    try {
      for (const k of Object.keys(client._memoCache || {})) delete client._memoCache[k];
    } catch {}
    try {
      client.$emt?.({ name: 'values_updated' });
    } catch {}
    return true;
  };
  const boot = () => {
    const S = window.__STATSIG__;
    const client = S?.firstInstance || (S?.instances && Object.values(S.instances)[0]);
    return patchClient(client);
  };
  window.__codex56ForcePatch = boot;
  let n = 0;
  const t = setInterval(() => {
    if (boot() || ++n > 200) clearInterval(t);
  }, 100);
  try {
    let _s = window.__STATSIG__;
    Object.defineProperty(window, '__STATSIG__', {
      configurable: true,
      enumerable: true,
      get() { return _s; },
      set(v) {
        _s = v;
        setTimeout(boot, 0);
        setTimeout(boot, 50);
        setTimeout(boot, 200);
      }
    });
  } catch {}
  boot();
  return 'installed';
})();
"""


async def main() -> int:
    list_url = f"http://{CDP_HOST}:{CDP_PORT}/json/list"
    try:
        pages = json.load(urllib.request.urlopen(list_url, timeout=2))
    except Exception as e:
        print("CDP unavailable:", e)
        print(
            'Launch first:\n'
            '  open -na "/Applications/ChatGPT.app" --args '
            "--remote-debugging-port=9222 --remote-allow-origins=*"
        )
        return 1

    if not pages:
        print("No CDP pages found")
        return 1

    # Prefer a page that looks like the main renderer
    page = pages[0]
    for p in pages:
        title = (p.get("title") or "") + " " + (p.get("url") or "")
        if "codex" in title.lower() or "chatgpt" in title.lower() or p.get("type") == "page":
            page = p
            break

    wsurl = page["webSocketDebuggerUrl"]
    print(f"CDP page: {page.get('title')!r} {page.get('url')}")

    async with websockets.connect(wsurl, max_size=20_000_000) as ws:
        msg_id = 0

        async def call(method, params=None):
            nonlocal msg_id
            msg_id += 1
            payload = {"id": msg_id, "method": method}
            if params is not None:
                payload["params"] = params
            await ws.send(json.dumps(payload))
            while True:
                data = json.loads(await ws.recv())
                if data.get("id") == msg_id:
                    return data

        await call("Runtime.enable")
        await call("Page.enable")
        await call("Page.addScriptToEvaluateOnNewDocument", {"source": INJECT})
        await call("Runtime.evaluate", {"expression": INJECT, "returnByValue": True})
        await call("Page.reload", {"ignoreCache": True})
        await asyncio.sleep(4)

        for _ in range(50):
            await call(
                "Runtime.evaluate",
                {
                    "expression": "window.__codex56ForcePatch && window.__codex56ForcePatch()",
                    "returnByValue": True,
                },
            )
            r = await call(
                "Runtime.evaluate",
                {
                    "expression": f"""
(() => {{
  const c = window.__STATSIG__?.firstInstance
    || (window.__STATSIG__?.instances && Object.values(window.__STATSIG__.instances)[0]);
  if (!c) return null;
  const value = c.getDynamicConfig('{CONFIG_NAME}')?.value;
  return {{
    patched: !!c.__codex56Patched,
    value
  }};
}})()
""".strip(),
                    "returnByValue": True,
                },
            )
            val = r.get("result", {}).get("result", {}).get("value")
            if (
                val
                and isinstance(val.get("value"), dict)
                and val["value"].get("use_hidden_models") is False
                and "gpt-5.6-sol" in (val["value"].get("available_models") or [])
            ):
                print(json.dumps(val, ensure_ascii=False, indent=2))
                # best-effort read footer chip text
                chip = await call(
                    "Runtime.evaluate",
                    {
                        "expression": """
(() => [...document.querySelectorAll('button')]
  .map(b => (b.innerText||'').replace(/\\s+/g,' ').trim())
  .filter(t => /5\\.|Sol|Terra|Luna|GPT-5|自定义|Custom/.test(t))
  .slice(0, 8)
)()
""".strip(),
                        "returnByValue": True,
                    },
                )
                print("model chips:", chip.get("result", {}).get("result", {}).get("value"))
                print("OK — reopen the model picker. Expect 5.6 Sol/Terra/Luna.")
                print("Note: this patch is in-memory; re-run after every app restart.")
                return 0
            await asyncio.sleep(0.25)

        print("FAILED to confirm Statsig patch")
        return 2


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
