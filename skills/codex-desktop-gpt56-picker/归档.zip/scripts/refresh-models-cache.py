#!/usr/bin/env python3
"""Refresh ~/.codex models_cache.json + model_catalog.json for Codex Desktop.

Priority:
1) Online Codex-style model manifests from provider base_url
2) Bundled assets/models_cache.example.json
3) Keep existing cache if it already contains gpt-5.6-*

Also best-effort patches config.toml model + model_catalog_json.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

CODEX_HOME = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
CACHE_PATH = CODEX_HOME / "models_cache.json"
CATALOG_PATH = CODEX_HOME / "model_catalog.json"
CONFIG_PATH = CODEX_HOME / "config.toml"
AUTH_PATH = CODEX_HOME / "auth.json"
SKILL_ROOT = Path(__file__).resolve().parent.parent
EXAMPLE_CACHE = SKILL_ROOT / "assets" / "models_cache.example.json"

DEFAULT_CLIENT_VERSION = "0.144.0"
TARGET_SLUGS = ("gpt-5.6-sol", "gpt-5.6-terra", "gpt-5.6-luna")


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def read_toml_simple(path: Path) -> dict[str, str]:
    """Tiny TOML string extractor for config.toml (no full parser dependency)."""
    if not path.exists():
        return {}
    text = path.read_text(encoding="utf-8", errors="replace")
    out: dict[str, str] = {}
    section = ""
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            continue
        m = re.match(r'^([A-Za-z0-9_]+)\s*=\s*"(.*)"\s*$', line)
        if not m:
            m = re.match(r"^([A-Za-z0-9_]+)\s*=\s*'(.*)'\s*$", line)
        if not m:
            continue
        key, val = m.group(1), m.group(2)
        full = f"{section}.{key}" if section else key
        out[full] = val
        out[key] = val  # last wins for bare keys
    return out


def load_api_key(explicit: str | None) -> str | None:
    if explicit:
        return explicit
    for env in ("OPENAI_API_KEY", "CODEX_API_KEY", "SUB2API_API_KEY"):
        if os.environ.get(env):
            return os.environ[env]
    if AUTH_PATH.exists():
        try:
            data = json.loads(AUTH_PATH.read_text(encoding="utf-8"))
        except Exception:
            data = {}
        for key in ("OPENAI_API_KEY", "access_token", "token", "api_key"):
            if data.get(key):
                return str(data[key])
        # nested shapes
        tokens = data.get("tokens") or {}
        if isinstance(tokens, dict):
            for key in ("access_token", "api_key"):
                if tokens.get(key):
                    return str(tokens[key])
    return None


def resolve_base_url(explicit: str | None, cfg: dict[str, str]) -> str | None:
    if explicit:
        return explicit.rstrip("/")
    for key in (
        "model_providers.OpenAI.base_url",
        "base_url",
    ):
        if cfg.get(key):
            return cfg[key].rstrip("/")
    # scan any model_providers.*.base_url
    for k, v in cfg.items():
        if k.endswith(".base_url") and "model_providers." in k:
            return v.rstrip("/")
    return None


def http_get_json(url: str, api_key: str | None, timeout: float = 20.0):
    headers = {"Accept": "application/json", "User-Agent": "codex-desktop-gpt56-picker/1.0"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = resp.read()
    return json.loads(body.decode("utf-8", errors="replace"))


def normalize_models_payload(payload) -> list[dict]:
    if isinstance(payload, dict):
        if isinstance(payload.get("models"), list):
            models = payload["models"]
        elif isinstance(payload.get("data"), list):
            models = payload["data"]
        else:
            models = []
    elif isinstance(payload, list):
        models = payload
    else:
        models = []

    out: list[dict] = []
    for item in models:
        if not isinstance(item, dict):
            continue
        slug = item.get("slug") or item.get("id") or item.get("model")
        if not slug:
            continue
        m = dict(item)
        m["slug"] = slug
        # OpenAI /v1/models style is sparse; keep only rich Codex manifests
        if "display_name" not in m and "supported_reasoning_levels" not in m:
            # too sparse for Desktop picker metadata — still keep if already rich enough later
            pass
        out.append(m)
    return out


def is_rich_codex_model(m: dict) -> bool:
    return bool(m.get("display_name") and m.get("supported_reasoning_levels"))


def fetch_online(base_url: str, api_key: str | None, client_version: str) -> list[dict] | None:
    paths = [
        f"/models?client_version={client_version}",
        f"/v1/models?client_version={client_version}",
        f"/backend-api/codex/models?client_version={client_version}",
        "/v1/models",
        "/models",
    ]
    best: list[dict] = []
    for path in paths:
        url = base_url.rstrip("/") + path
        try:
            payload = http_get_json(url, api_key)
            models = normalize_models_payload(payload)
        except Exception as e:
            print(f"  skip {url}: {e}")
            continue
        rich = [m for m in models if is_rich_codex_model(m)]
        print(f"  hit {url}: total={len(models)} rich={len(rich)}")
        if len(rich) > len(best):
            best = rich
        # good enough if we already have 5.6
        slugs = {m.get("slug") for m in rich}
        if all(s in slugs for s in TARGET_SLUGS):
            return rich
    return best or None


def load_example() -> dict:
    if not EXAMPLE_CACHE.exists():
        raise SystemExit(f"Missing fallback asset: {EXAMPLE_CACHE}")
    return json.loads(EXAMPLE_CACHE.read_text(encoding="utf-8"))


def existing_has_targets() -> dict | None:
    if not CACHE_PATH.exists():
        return None
    try:
        data = json.loads(CACHE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return None
    models = data.get("models") if isinstance(data, dict) else None
    if not isinstance(models, list):
        return None
    slugs = {m.get("slug") for m in models if isinstance(m, dict)}
    if all(s in slugs for s in TARGET_SLUGS):
        return data
    return None


def ensure_config(catalog_path: Path, set_default_model: bool) -> None:
    if not CONFIG_PATH.exists():
        print(f"config missing: {CONFIG_PATH} (skip config patch)")
        return
    text = CONFIG_PATH.read_text(encoding="utf-8", errors="replace")
    original = text
    abs_catalog = str(catalog_path.resolve())

    if re.search(r"(?m)^\s*model_catalog_json\s*=", text):
        text = re.sub(
            r'(?m)^\s*model_catalog_json\s*=\s*".*"\s*$',
            f'model_catalog_json = "{abs_catalog}"',
            text,
            count=1,
        )
    else:
        # insert near top after model_provider if present
        if re.search(r"(?m)^\s*model_provider\s*=", text):
            text = re.sub(
                r"(?m)^(\s*model_provider\s*=.*)$",
                rf'\1\nmodel_catalog_json = "{abs_catalog}"',
                text,
                count=1,
            )
        else:
            text = f'model_catalog_json = "{abs_catalog}"\n' + text

    if set_default_model:
        if re.search(r"(?m)^\s*model\s*=", text):
            text = re.sub(r'(?m)^\s*model\s*=\s*".*"\s*$', 'model = "gpt-5.6-sol"', text, count=1)
        else:
            text = 'model = "gpt-5.6-sol"\n' + text

    if text != original:
        bak = CONFIG_PATH.with_suffix(CONFIG_PATH.suffix + f".bak-gpt56-{datetime.now().strftime('%Y%m%d%H%M%S')}")
        bak.write_text(original, encoding="utf-8")
        CONFIG_PATH.write_text(text, encoding="utf-8")
        print(f"updated config: {CONFIG_PATH} (backup {bak.name})")
    else:
        print("config already points at catalog / model")


def write_cache(models: list[dict], client_version: str) -> None:
    CODEX_HOME.mkdir(parents=True, exist_ok=True)
    if CACHE_PATH.exists():
        bak = CACHE_PATH.with_suffix(CACHE_PATH.suffix + f".bak-{datetime.now().strftime('%Y%m%d%H%M%S')}")
        bak.write_bytes(CACHE_PATH.read_bytes())
        print(f"backup cache -> {bak}")

    payload = {
        "fetched_at": utc_now(),
        "client_version": client_version,
        "models": models,
    }
    CACHE_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    CATALOG_PATH.write_text(json.dumps({"models": models}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {CACHE_PATH}")
    print(f"wrote {CATALOG_PATH}")
    print("models:", ", ".join(m.get("slug", "?") for m in models))


def main() -> int:
    ap = argparse.ArgumentParser(description="Refresh Codex Desktop model cache for GPT-5.6")
    ap.add_argument("--base-url", help="Provider base URL, e.g. https://code.example.com")
    ap.add_argument("--api-key", help="Bearer API key")
    ap.add_argument("--client-version", default=DEFAULT_CLIENT_VERSION)
    ap.add_argument("--force-example", action="store_true", help="Skip network; use bundled example")
    ap.add_argument("--no-set-default-model", action="store_true")
    args = ap.parse_args()

    cfg = read_toml_simple(CONFIG_PATH)
    base_url = resolve_base_url(args.base_url, cfg)
    api_key = load_api_key(args.api_key)

    models: list[dict] | None = None
    source = ""

    if not args.force_example and base_url:
        print(f"fetching models from {base_url} ...")
        models = fetch_online(base_url, api_key, args.client_version)
        if models:
            source = f"online:{base_url}"

    if not models:
        existing = existing_has_targets()
        if existing and not args.force_example:
            print("online fetch incomplete; keeping existing cache that already has 5.6")
            models = existing["models"]
            source = "existing-cache"
            # still refresh timestamps / catalog pointer
            write_cache(models, existing.get("client_version") or args.client_version)
            ensure_config(CATALOG_PATH, set_default_model=not args.no_set_default_model)
            print(f"source={source}")
            return 0

        print("using bundled example cache")
        example = load_example()
        models = example.get("models") or []
        source = "bundled-example"
        client_version = example.get("client_version") or args.client_version
    else:
        client_version = args.client_version

    if not models:
        print("ERROR: no models available", file=sys.stderr)
        return 2

    slugs = {m.get("slug") for m in models if isinstance(m, dict)}
    missing = [s for s in TARGET_SLUGS if s not in slugs]
    if missing:
        print(f"WARNING: missing target slugs: {missing}")
        if source.startswith("online"):
            print("falling back to bundled example for full 5.6 metadata")
            example = load_example()
            models = example.get("models") or models
            source = "bundled-example-fallback"
            client_version = example.get("client_version") or client_version

    write_cache(models, client_version)
    ensure_config(CATALOG_PATH, set_default_model=not args.no_set_default_model)
    print(f"source={source}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
