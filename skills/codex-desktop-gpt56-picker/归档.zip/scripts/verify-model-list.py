#!/usr/bin/env python3
"""Verify `codex app-server` model/list includes GPT-5.6 family."""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import threading
import time

TARGETS = ("gpt-5.6-sol", "gpt-5.6-terra", "gpt-5.6-luna")


def main() -> int:
    codex = shutil.which("codex")
    if not codex:
        print("ERROR: `codex` CLI not found on PATH", file=sys.stderr)
        return 2

    proc = subprocess.Popen(
        [codex, "app-server", "--listen", "stdio://"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    assert proc.stdin and proc.stdout

    out: list[dict] = []

    def reader() -> None:
        for line in proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            out.append(msg)
            if msg.get("id") == 1:
                return

    t = threading.Thread(target=reader, daemon=True)
    t.start()

    reqs = [
        {
            "jsonrpc": "2.0",
            "id": "init",
            "method": "initialize",
            "params": {
                "clientInfo": {"name": "Codex Desktop", "version": "26.707.31428"},
                "capabilities": {},
            },
        },
        {"jsonrpc": "2.0", "method": "initialized", "params": {}},
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "model/list",
            "params": {"includeHidden": True, "limit": 100, "cursor": None},
        },
    ]
    try:
        for r in reqs:
            proc.stdin.write(json.dumps(r) + "\n")
            proc.stdin.flush()
            time.sleep(0.15)
        t.join(timeout=10)
    finally:
        try:
            proc.terminate()
        except Exception:
            pass
        try:
            proc.kill()
        except Exception:
            pass

    result = next((m for m in out if m.get("id") == 1), None)
    if not result:
        print("ERROR: no model/list response")
        err = ""
        try:
            err = proc.stderr.read() if proc.stderr else ""
        except Exception:
            pass
        if err:
            print(err[:2000])
        return 3

    if "error" in result:
        print("ERROR:", json.dumps(result["error"], ensure_ascii=False))
        return 4

    models = result.get("result", {}).get("data") or []
    slugs = [m.get("model") or m.get("slug") for m in models]
    print("model/list:", ", ".join(slugs))

    missing = [s for s in TARGETS if s not in slugs]
    if missing:
        print("FAIL missing:", ", ".join(missing))
        print("Fix Layer A: run scripts/refresh-models-cache.py")
        return 5

    print("OK — app-server exposes GPT-5.6 family")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
