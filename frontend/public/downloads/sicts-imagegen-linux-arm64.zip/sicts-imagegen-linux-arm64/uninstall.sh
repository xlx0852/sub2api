#!/usr/bin/env bash
set -euo pipefail
CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
DEST="$CODEX_HOME/skills/sicts-imagegen"
if [ -d "$DEST" ]; then
  rm -rf "$DEST"
  echo "removed $DEST"
else
  echo "not installed: $DEST"
fi
echo "Note: [[skills.config]] entries in config.toml are left intact; remove manually if needed."
