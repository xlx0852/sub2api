# sicts-imagegen (universal / all platforms)

**One package for all OS/CPU.** Installer auto-selects the correct CLI binary for this machine.

## Recommended: attach zip in Codex

1. Attach this zip in **Codex Desktop / ChatGPT.app**
2. Send:

```text
安装一下这个插件
```

3. Fully quit and restart the app, open a **new** chat, then try:

```text
用 $sicts-imagegen 生成一张测试图
```

## Alternate: terminal install (macOS / Linux)

```bash
unzip sicts-imagegen-all.zip
cd sicts-imagegen-all
./install.sh
```

## Alternate: terminal install (Windows PowerShell)

```powershell
Expand-Archive sicts-imagegen-all.zip -DestinationPath .
cd sicts-imagegen-all
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

### What install does

1. Detects OS + CPU
2. Copies skill into `~/.codex/skills/sicts-imagegen`
3. Installs the matching binary as `scripts/sicts-image-gen` (or `.exe`)
4. Keeps all platform binaries under `bin/<platform>/` (for re-install elsewhere)
5. Sets `enabled = true` for this skill; disables system `imagegen`
6. Does **not** rewrite your model providers / API keys

Optional:

```bash
# do not disable system imagegen
SICTS_DISABLE_SYSTEM_IMAGEGEN=0 ./install.sh

# only keep the selected platform binary (smaller install)
SICTS_INSTALL_STRIP_OTHER_BINS=1 ./install.sh
```

## Layout

```
sicts-imagegen-all/
  install.sh
  install.ps1
  uninstall.sh
  README.md
  skills/sicts-imagegen/
    SKILL.md
    scripts/
      remove_chroma_key.py
      sicts-image-gen          # created at install time for this host
    bin/
      darwin-arm64/sicts-image-gen
      darwin-x64/sicts-image-gen
      linux-arm64/sicts-image-gen
      linux-x64/sicts-image-gen
      windows-x64/sicts-image-gen.exe
      windows-arm64/sicts-image-gen.exe
```

## After install

Restart ChatGPT.app / Codex Desktop, open a **new** chat:

```text
用 $sicts-imagegen 生成一张测试图
```

Chroma cutout (local, needs python3 + Pillow):

```bash
~/.codex/skills/sicts-imagegen/scripts/sicts-image-gen remove-chroma \
  --input in-chroma.png --out out.png --auto-key border --force
```

## Version

- CLI: 0.1.2
- Built: 20260719T133115Z
