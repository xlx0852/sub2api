# Universal Windows installer for sicts-imagegen
# Auto-selects windows-x64 / windows-arm64 binary for Codex.
$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$CodexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE ".codex" }
$Dest = Join-Path $CodexHome "skills\sicts-imagegen"
$DisableSystem = if ($env:SICTS_DISABLE_SYSTEM_IMAGEGEN) { $env:SICTS_DISABLE_SYSTEM_IMAGEGEN } else { "1" }

function Get-PlatformId {
  $arch = $env:PROCESSOR_ARCHITECTURE
  switch -Regex ($arch) {
    'ARM64' { return 'windows-arm64' }
    'AMD64|x86' { return 'windows-x64' }
    default { throw "Unsupported architecture: $arch" }
  }
}

$Platform = Get-PlatformId
$BinSrc = Join-Path $Root "skills\sicts-imagegen\bin\$Platform\sicts-image-gen.exe"
if (-not (Test-Path $BinSrc)) {
  throw "Missing binary for $Platform : $BinSrc"
}

Write-Host "==> sicts-imagegen universal install"
Write-Host "    platform: $Platform"
Write-Host "    dest:     $Dest"

New-Item -ItemType Directory -Force -Path (Join-Path $CodexHome "skills") | Out-Null
if (Test-Path $Dest) { Remove-Item -Recurse -Force $Dest }
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Copy-Item -Recurse -Force (Join-Path $Root "skills\sicts-imagegen\*") $Dest

$Scripts = Join-Path $Dest "scripts"
New-Item -ItemType Directory -Force -Path $Scripts | Out-Null
Copy-Item -Force $BinSrc (Join-Path $Scripts "sicts-image-gen.exe")
# Some shells look for no extension
Copy-Item -Force $BinSrc (Join-Path $Scripts "sicts-image-gen")

@"
platform=$Platform
source=bin/$Platform/sicts-image-gen.exe
installed_as=scripts/sicts-image-gen.exe
selected_utc=$((Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ"))
"@ | Set-Content -Encoding utf8 (Join-Path $Scripts "SELECTED_PLATFORM.txt")

$Cfg = Join-Path $CodexHome "config.toml"
$SkillMd = Join-Path $Dest "SKILL.md"
$Patch = Join-Path $Root "patch_skills_config.py"
$Py = if (Get-Command python -ErrorAction SilentlyContinue) { "python" } else { "python3" }
& $Py $Patch $Cfg $SkillMd $CodexHome $DisableSystem

$Active = Join-Path $Scripts "sicts-image-gen.exe"
Write-Host "==> self-check"
& $Active --version
Write-Host ""
Write-Host "Done. Platform: $Platform"
Write-Host "Binary: $Active"
Write-Host "Restart Codex / ChatGPT and open a NEW chat."
