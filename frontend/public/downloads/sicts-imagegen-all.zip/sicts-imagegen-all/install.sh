#!/usr/bin/env bash
# Universal installer: auto-selects OS/CPU binary into scripts/ for Codex.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
DEST="$CODEX_HOME/skills/sicts-imagegen"
export SICTS_DISABLE_SYSTEM_IMAGEGEN="${SICTS_DISABLE_SYSTEM_IMAGEGEN:-1}"

detect_platform() {
  local os arch
  os="$(uname -s 2>/dev/null || echo unknown)"
  arch="$(uname -m 2>/dev/null || echo unknown)"
  case "$os" in
    Darwin)
      case "$arch" in
        arm64|aarch64) echo "darwin-arm64" ;;
        x86_64|amd64)  echo "darwin-x64" ;;
        *) echo "unsupported:darwin-$arch" ;;
      esac
      ;;
    Linux)
      case "$arch" in
        aarch64|arm64) echo "linux-arm64" ;;
        x86_64|amd64)  echo "linux-x64" ;;
        *) echo "unsupported:linux-$arch" ;;
      esac
      ;;
    MINGW*|MSYS*|CYGWIN*)
      case "$arch" in
        aarch64|arm64) echo "windows-arm64" ;;
        x86_64|amd64|i686|i386) echo "windows-x64" ;;
        *) echo "unsupported:windows-$arch" ;;
      esac
      ;;
    *)
      echo "unsupported:$os-$arch"
      ;;
  esac
}

platform_bin_name() {
  case "$1" in
    windows-*) echo "sicts-image-gen.exe" ;;
    *) echo "sicts-image-gen" ;;
  esac
}

echo "==> sicts-imagegen universal install"
echo "    package root: $ROOT"
echo "    codex home:   $CODEX_HOME"

PLATFORM="$(detect_platform)"
if [[ "$PLATFORM" == unsupported:* ]]; then
  echo "ERROR: unsupported platform: ${PLATFORM#unsupported:}" >&2
  echo "Supported: darwin-arm64 darwin-x64 linux-arm64 linux-x64 windows-x64 windows-arm64" >&2
  echo "On Windows prefer: powershell -File install.ps1" >&2
  exit 1
fi

BIN_SRC_NAME="$(platform_bin_name "$PLATFORM")"
BIN_SRC="$ROOT/skills/sicts-imagegen/bin/$PLATFORM/$BIN_SRC_NAME"
if [[ ! -f "$BIN_SRC" ]]; then
  echo "ERROR: missing binary for $PLATFORM: $BIN_SRC" >&2
  echo "Available platforms:" >&2
  ls -1 "$ROOT/skills/sicts-imagegen/bin" 2>/dev/null || true
  exit 1
fi

BIN_DST_NAME="$BIN_SRC_NAME"
# On Unix always install as sicts-image-gen (skill expects this name)
if [[ "$PLATFORM" != windows-* ]]; then
  BIN_DST_NAME="sicts-image-gen"
fi

echo "==> detected platform: $PLATFORM"
echo "==> binary: $BIN_SRC"

mkdir -p "$CODEX_HOME/skills"
rm -rf "$DEST"
mkdir -p "$DEST"

# Copy skill tree (docs + all bins + scripts helpers)
cp -R "$ROOT/skills/sicts-imagegen/." "$DEST/"

# Activate host binary as the default CLI name Codex/skill invokes
mkdir -p "$DEST/scripts"
cp "$BIN_SRC" "$DEST/scripts/$BIN_DST_NAME"
chmod +x "$DEST/scripts/$BIN_DST_NAME" 2>/dev/null || true
# Also keep a stable non-.exe name on Windows Git-Bash if possible
if [[ "$BIN_DST_NAME" == *.exe ]]; then
  cp "$BIN_SRC" "$DEST/scripts/sicts-image-gen.exe"
fi

# Record which binary was selected
cat >"$DEST/scripts/SELECTED_PLATFORM.txt" <<SEL
platform=$PLATFORM
source=bin/$PLATFORM/$BIN_SRC_NAME
installed_as=scripts/$BIN_DST_NAME
selected_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)
SEL

# Optional: drop other platform bins to save space (keep by default for re-select)
if [[ "${SICTS_INSTALL_STRIP_OTHER_BINS:-0}" == "1" ]]; then
  echo "==> stripping other platform binaries (SICTS_INSTALL_STRIP_OTHER_BINS=1)"
  find "$DEST/bin" -mindepth 1 -maxdepth 1 ! -name "$PLATFORM" -exec rm -rf {} +
fi

CFG="$CODEX_HOME/config.toml"
python3 "$ROOT/patch_skills_config.py" \
  "$CFG" "$DEST/SKILL.md" "$CODEX_HOME" "$SICTS_DISABLE_SYSTEM_IMAGEGEN"

echo "==> self-check"
ACTIVE="$DEST/scripts/$BIN_DST_NAME"
if [[ -x "$ACTIVE" ]] || [[ -f "$ACTIVE" ]]; then
  "$ACTIVE" --version 2>/dev/null || true
  "$ACTIVE" --print-config --dry-run generate --prompt 'install-probe' --out /tmp/sicts-imagegen-install-probe.png || true
  if command -v python3 >/dev/null 2>&1 && [[ -f "$DEST/scripts/remove_chroma_key.py" ]]; then
    echo "==> chroma helper present: $DEST/scripts/remove_chroma_key.py"
  fi
else
  echo "WARN: active binary not executable: $ACTIVE" >&2
fi

echo ""
echo "Done. Platform selected: $PLATFORM"
echo "Binary: $ACTIVE"
echo "1) Restart ChatGPT.app / Codex Desktop"
echo "2) Open a NEW chat: 用 \$sicts-imagegen 生成一张测试图"
echo "Re-run this installer on another machine to auto-pick that host's binary."
echo "Disable system imagegen skip: SICTS_DISABLE_SYSTEM_IMAGEGEN=0 ./install.sh"
