# sicts-imagegen (macos-arm64)

Single-platform package. For auto platform selection, use `sicts-imagegen-all.zip`.

## Recommended: attach zip in Codex

1. Attach this zip in **Codex Desktop / ChatGPT.app**
2. Send:

```text
安装一下这个插件
```

3. Fully quit and restart the app, open a **new** chat.

## Alternate: terminal

```bash
./install.sh
```
