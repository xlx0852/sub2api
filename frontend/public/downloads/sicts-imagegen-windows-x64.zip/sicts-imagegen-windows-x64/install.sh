#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
DEST="$CODEX_HOME/skills/sicts-imagegen"
BIN_NAME="sicts-image-gen.exe"
export SICTS_DISABLE_SYSTEM_IMAGEGEN="${SICTS_DISABLE_SYSTEM_IMAGEGEN:-1}"

echo "==> install sicts-imagegen (windows-x64) into $DEST"
mkdir -p "$CODEX_HOME/skills"
rm -rf "$DEST"
mkdir -p "$DEST"
cp -R "$ROOT/skills/sicts-imagegen/." "$DEST/"
chmod +x "$DEST/scripts/$BIN_NAME" 2>/dev/null || true

python3 "$ROOT/patch_skills_config.py" \
  "$CODEX_HOME/config.toml" "$DEST/SKILL.md" "$CODEX_HOME" "$SICTS_DISABLE_SYSTEM_IMAGEGEN"

if [ -x "$DEST/scripts/$BIN_NAME" ] || [ -f "$DEST/scripts/$BIN_NAME" ]; then
  "$DEST/scripts/$BIN_NAME" --version 2>/dev/null || true
  "$DEST/scripts/$BIN_NAME" --print-config --dry-run generate --prompt 'install-probe' --out /tmp/sicts-imagegen-install-probe.png || true
fi
echo "Done. Restart Codex and open a new chat."
